export class ExamData{
  constructor(public qid:number,
  public testid:number,
  public selectedOption:number){}
}
