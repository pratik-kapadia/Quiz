export class ObjectiveOption{
  id:number;
  value:string;
  isCorrect:boolean;
  selectedOption:string;
}
