import { ObjectiveOption } from "./objectiveOption";

export interface ITest{
  id:number,
  title:string,
  description:string,
  duration:string,
}
