export class ObjectiveSelectOption{
  constructor(public id:number, public value:string){}
}
