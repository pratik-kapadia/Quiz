export class User{
  firstName:string;
  lastName:string;
  age:number;
  contact:number
}
