export interface ISkill{
  skillName: string;
  experienceInYears: number;
  proficiency: string;
}
